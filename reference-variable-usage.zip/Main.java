/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Animal
{
   String color; // Declaring Objects through Reference Variable
   int age;
}
public class Main
{
	public static void main(String[] args) {
		Animal Leopard = new Animal();
		Leopard.color = "Golden";  // Using Reference Variable to define the speciality of the Objects
		Leopard.age = 18;
		System.out.println(Leopard.color+" Color and age "+Leopard.age);
	}
}
