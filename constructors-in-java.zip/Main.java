/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


*******************************************************************************/
            //*****************Default Constructor*************************//

// class Test
// {
//     int i;
//     String s;
// }
// public class Main
// {
// 	public static void main(String[] args) {
// 		Test t = new Test();
// 		System.out.println(t.i+" "+t.s); // output is 0 and Null and this value is assigned by default Constructors.
		
// 	}
// }
      // ************************No Argument Constructor****************//
// class Test{
//     Test()
//     {
//         System.out.println("No argument Constructor");
//     }
// }
// public class Main
// {
//     public static void main(String[] args)
//     {
//         Test t = new Test();
//     }
// }

  // ***************************Parameterised Constructor*****************************//
  
class Test
{
    String s;
    int age;
    Test(String s,int age)
    {
        this.s = s;
        this.age = age;
    }
}
public class Main{
    public static void main(String[] args)
    {
        Test t = new Test("Deepak",19);
        System.out.println(t.s+" "+t.age);
    }
}
