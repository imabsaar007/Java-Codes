/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Animal
{
    String color;
    int age;
    public void init(String s,int a)
    {
        color = s;
        age = a;
    }
    public void display()
    {
        System.out.println(color+" "+age);
    }
}
public class Main
{
	public static void main(String[] args) {
		Animal Jaguar = new Animal();
		Jaguar.init("Black",18);
		Jaguar.display();
	}
}
